package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText et_id, et_pw, et_pw_chk;
    String sId, sPw, sPw_chk;

    String id = "1";
    String pw = "1";
    int market_1 = 1;
    int market_2 = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et_id = (EditText) findViewById(R.id.et_Id);
        et_pw = (EditText) findViewById(R.id.et_Password);

    }

    public void btn_temp_Click(View view){
        ImageView image = (ImageView)findViewById(R.id.imageView);

        //image.setImageResource(R.drawable.b);
    }
    public void btn1_clicked(View v) {
        Toast.makeText(this,"clicked",Toast.LENGTH_LONG).show();
    }
    public void onLogIn_Clicked(View v) {

        sId = et_id.getText().toString();
        sPw = et_pw.getText().toString();

        if (sId.equals(id) && sPw.equals(pw)) {   // ID,PW 모두 일치할 때 화면 전환
            Toast.makeText(this, "LogIn Complete!", Toast.LENGTH_LONG).show();
            Intent mainintent = new Intent(getApplicationContext(), MainScreen.class);
            mainintent.putExtra("id", sId);
            mainintent.putExtra("market_1_data", market_1);
            mainintent.putExtra("market_2_data", market_2);
            startActivity(mainintent);
        }
        else{
            Toast.makeText(this, "LogIn Failed!", Toast.LENGTH_LONG).show();
        }


    }
}