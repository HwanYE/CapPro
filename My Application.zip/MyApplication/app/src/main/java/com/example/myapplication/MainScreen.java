package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_screen);

        TextView username = (TextView)findViewById(R.id.txt_display_name);

        Intent intent = getIntent();
        String id = intent.getStringExtra("id");
        int market_1 = intent.getIntExtra("market_1_data",1);
        int market_2 = intent.getIntExtra("market_2_data",1);

        if(market_1 == 1){
            ImageView image = (ImageView)findViewById(R.id.img_marketinfo);

            image.setImageResource(R.drawable.img_possible);
        }
        if(market_2 == 0){
            ImageView image = (ImageView)findViewById(R.id.img_marketinfo2);

            image.setImageResource(R.drawable.img_impossible);
        }
        username.setText("환영합니다!" + id);
    }

    public void btn_market_more_Clicked(View view){
        Intent marketinfo = new Intent(getApplicationContext(), ActivityMarketInfo.class);

        startActivity(marketinfo);
    }
}